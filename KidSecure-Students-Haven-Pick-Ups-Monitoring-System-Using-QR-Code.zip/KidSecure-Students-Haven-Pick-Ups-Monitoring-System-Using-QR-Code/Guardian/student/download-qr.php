<?php
session_start(); // Start the session
include '../../Config/connection.php';
require_once '../../library/phpqrcode/qrlib.php'; 

if (!isset($_GET['qr_code'])) {
    die("QR code data is missing.");
}

$qrCodeData = $_GET['qr_code'];

// Set headers for file download
header('Content-Type: image/png');
header('Content-Disposition: attachment; filename="qr_code.png"');

// Generate the QR code and output it directly
QRcode::png($qrCodeData, null, QR_ECLEVEL_L, 10);
exit;
?>
