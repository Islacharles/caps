<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';
$_SESSION['header'] = 'Child';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Records</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link href="index.css" rel="stylesheet" /> 
    <!-- Include Local DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="datatables.min.css">
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main">
        <div class="main-wrapper-body card-container">
            <div class="row">
                <div class="col-md-12">
                    <div class="search-field" style="display: flex;"> 
                        <input type="text" id="searchField" class="form-control" placeholder="Search Students..." onkeyup="searchTable()"> 
                    </div>
                    <br>
                </div>
                <div class="col-12 row" id="student-content">
                    <!-- Student cards will be appended here -->
                </div>
            </div>
        </div>
        <div class="main-wrapper-body card-container">
            <h3 class="fw-bold">Attendance</h3>
            <hr>
            <div class="table-container">
                <div class="row mb-4">
                    <div class="col-md-12 text-end">
                        <button class="btn btn-success" id="exportReport">Generate Report</button>
                    </div>
                </div>
                <table class="table table-striped table-bordered" id="attendanceTable">
                    <thead class="table-dark">
                        <tr>
                            <th>Student #</th>
                            <th>Full Name</th>
                            <th>Grade Level</th>
                            <th>Section</th>
                            <th>Date</th>
                            <th>Time In</th>
                            <th>Time Out</th>
                            <th>Authorize Person</th>
                        </tr>
                    </thead>
                    <tbody id="body-table">
                        <!-- Attendance data will be appended here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Include Local jQuery -->
    <script src="jquery.min.js"></script>
    <!-- Include Local DataTables JS -->
    <script src="datatables.min.js"></script>

    <script>
        $(document).ready(function () {
            // Initialize DataTable
            var table = $('#attendanceTable').DataTable();

            // Load initial data
            searchData();
            fetchData();

            // Search field functionality
            $("#searchField").on('keyup', function () {
                searchData($(this).val());
            });
            $('#exportReport').click(function () {
                exportReport();
            });
            // Fetch attendance data
            function fetchData() {
                var search = "<?=$_SESSION['id']?>";

                // AJAX GET request
                $.ajax({
                    url: 'search-attendance-api.php', // API URL
                    method: 'GET',
                    data: {
                        search: search
                    },
                    success: function (response) {
                        table.clear(); // Clear existing table data
                        response?.forEach(function (item) {
                            table.row.add([
                                item.student_number,
                                item.student_name,
                                item.grade_level,
                                item.section,
                                item.created_date,
                                item.time_in,
                                item.time_out,
                                item.authorize_fullname
                            ]);
                        });
                        table.draw(); // Redraw the table with new data
                    },
                    error: function () {
                        alert('An error occurred while fetching the data.');
                    }
                });
            }

            // Fetch and display student data
            function searchData(search = '') {
                $("#student-content").html(''); // Clear existing content

                $.ajax({
                    url: 'index-search-api.php', // API URL
                    type: 'GET',
                    data: {
                        search: search,
                        guardianId: "<?=$_SESSION['id']?>"
                    },
                    success: function (response) {
                        response?.forEach(obj => {
                            $("#student-content").append(`
                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="card-body">
                                        <img src="data:image/png;base64,${obj.picture}" alt="Student Picture">
                                        <div class="details">
                                            <p>${obj.student_name}</p>
                                            <small>${obj.grade_level}</small>
                                        </div>
                                        <div class="action">
                                            <a type="button" href="view.php?id=${obj.student_number}" ident="${obj.student_number}" class="btn btn-primary">View</a>
                                        </div>
                                    </div>
                                </div> 
                            `);
                        });
                    },
                    error: function (xhr, status, error) {
                        console.log("An error occurred: " + error);
                    }
                });
            }
            function exportReport() {
                var date = $('#filterDate').val();

                $.ajax({
                    url: 'export-attendance-student-api.php', // API for exporting report
                    method: 'POST',
                    data: { date: date },
                    xhrFields: {
                        responseType: 'blob' // Ensure the response is a binary blob (for Excel files)
                    },
                    success: function (response) {
                        var blob = response; // The server will send the Excel file as a blob
                        var link = document.createElement('a');
                        link.href = window.URL.createObjectURL(blob);
                        link.download = `Child_Attendance_Report.xlsx`; // Set the file extension to .xlsx
                        link.click();
                    },
                    error: function () {
                        alert('An error occurred while exporting the report.');
                    }
                });
            }
        });
        
    </script>
</body>
</html>