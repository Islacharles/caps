
<?php
    header('Location: events/')
?>