<?php
include '../../Config/api-config.php';
include '../../Config/connection.php'; // Opening database connection

// Parse the input POST data
$id = $_POST['id'] ?? null;

// Validate the ID
if (empty($id) || !is_numeric($id)) {
    http_response_code(400); // Bad Request
    echo json_encode([
        "status" => "error",
        "message" => "Invalid or missing ID."
    ]);
    exit();
}

// Prepare the SQL statement for archiving data
$sqlSelect = "SELECT FIRSTNAME, MIDDLENAME, LASTNAME, CONTACT_NUMBER, ADDRESS, PARENT_ID, PICTURE FROM authorize_person WHERE ID = ?";
$stmt = $conn->prepare($sqlSelect);
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();

// Check if the record exists
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Archive the data by inserting it into the archive table
    $sqlInsert = "INSERT INTO archive_tbl (FIRSTNAME, MIDDLENAME, LASTNAME, CONTACT_NUMBER, ADDRESS, PARENT_ID, PICTURE) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmtInsert = $conn->prepare($sqlInsert);
    $stmtInsert->bind_param('sssssss', $row['FIRSTNAME'], $row['MIDDLENAME'], $row['LASTNAME'], $row['CONTACT_NUMBER'], 
                            $row['ADDRESS'], $row['PARENT_ID'], $row['PICTURE']);

    if ($stmtInsert->execute()) {
        // Record successfully archived, now delete it from the original table
        $sqlDelete = "DELETE FROM authorize_person WHERE ID = ?";
        $stmtDelete = $conn->prepare($sqlDelete);
        $stmtDelete->bind_param('i', $id);

        if ($stmtDelete->execute()) {
            echo json_encode([
                "status" => "success",
                "message" => "Record archived successfully."
            ]);
        } else {
            http_response_code(500); // Internal Server Error
            echo json_encode([
                "status" => "error",
                "message" => "Failed to delete the record from authorize_person."
            ]);
        }
    } else {
        http_response_code(500); // Internal Server Error
        echo json_encode([
            "status" => "error",
            "message" => "Failed to archive the record. Please try again."
        ]);
    }
} else {
    http_response_code(404); // Not Found
    echo json_encode([
        "status" => "error",
        "message" => "Record not found."
    ]);
}

// Close the prepared statements and connection
$stmt->close();
$stmtInsert->close();
$stmtDelete->close();
$conn->close();
?>
