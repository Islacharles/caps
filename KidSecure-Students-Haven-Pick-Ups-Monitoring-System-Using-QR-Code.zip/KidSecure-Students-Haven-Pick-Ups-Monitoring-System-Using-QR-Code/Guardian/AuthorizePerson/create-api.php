<?php
include '../../Config/api-config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST'){
    exit();
}


// Collect data from POST
$firstName = $_POST["FirstName"] ?? '';
$middleName = $_POST["MiddleName"] ?? '';
$lastName = $_POST["LastName"] ?? '';
$contactNumber = $_POST["ContactNumber"] ?? '';
$address = $_POST["Address"] ?? '';
$parentId = $_POST["ParentID"] ?? '';
$pictureBase64 = $_POST['PictureBase64'] ?? null;

// Initialize an array to store validation errors
$validationErrors = [];

// Validate each field
$validationErrors['FirstName'] = validateField('FirstName', $firstName);
$validationErrors['MiddleName'] = validateField('MiddleName', $middleName, 80, false);
$validationErrors['LastName'] = validateField('LastName', $lastName);
$validationErrors['ContactNumber'] = validateField('ContactNumber', $contactNumber, 11, true, true);
$validationErrors['Address'] = validateField('Address', $address, 255);
// $validationErrors['ParentID'] = validateField('ParentID', $parentId, 0, true, true); // Required and numeric

// Remove fields with no errors
foreach ($validationErrors as $key => $value) {
    if (empty($value)) {
        unset($validationErrors[$key]);
    }
}

// Respond with validation errors
if (!empty($validationErrors)) {
    echo json_encode([
        'status' => 'error',
        'message' => $validationErrors
    ], JSON_PRETTY_PRINT);
    exit();
}

include '../../Config/connection.php'; // Opening database connection

// Insert into the `authorize_person` table
$sql = "INSERT INTO authorize_person (FIRSTNAME, MIDDLENAME, LASTNAME, CONTACT_NUMBER, ADDRESS, PARENT_ID, PICTURE) 
        VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

$pictureBase64;

$stmt->bind_param(
    "sssssis",
    $firstName,
    $middleName,
    $lastName,
    $contactNumber,
    $address,
    $parentId,
    $pictureBase64
);

// Execute the query
if ($stmt->execute()) {
    $response = [
        'status' => 'success',
        'message' => 'Authorized person added successfully!',
        'data' => [
            'id' => $stmt->insert_id,
            'firstName' => $firstName,
            'lastName' => $lastName
        ]
    ];
} else {
    $response = [
        'status' => 'error',
        'message' => 'Failed to add authorized person. ' . $stmt->error
    ];
}

// Close the statement and connection
$stmt->close();
$conn->close();

// Send the response
echo json_encode($response, JSON_PRETTY_PRINT);

// Helper function to validate input fields
function validateField($fieldName, $fieldValue, $maxLength = 80, $required = true, $numeric = false) {
    $errors = [];

    // Check if the field is required and not empty
    if ($required && empty($fieldValue)) {
        $errors[] = "$fieldName is required.";
    }

    // Check length
    if (!empty($fieldValue) && strlen($fieldValue) > $maxLength) {
        $errors[] = "$fieldName must not exceed $maxLength characters.";
    }

    // Check for numeric value
    if ($numeric && !empty($fieldValue) && !ctype_digit($fieldValue)) {
        $errors[] = "$fieldName must be a numeric value.";
    }

    // Check for special characters
    if (!empty($fieldValue) && !$numeric && preg_match('/[^a-zA-Z0-9\s]/', $fieldValue)) {
        $errors[] = "$fieldName must not contain special characters.";
    }

    return $errors;
}
?>