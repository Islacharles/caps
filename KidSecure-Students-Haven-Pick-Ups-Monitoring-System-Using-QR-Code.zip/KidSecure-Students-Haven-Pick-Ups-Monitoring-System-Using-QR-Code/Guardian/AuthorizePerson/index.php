<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';
$_SESSION['header'] = 'Authorize Persons';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Records</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link href="index.css" rel="stylesheet" />
    <title>Student Records</title>
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main ">
        <div class="container card-container">
            <div class="row"> 
                <div class="col-12">
                    <div class="search-field" style="display: flex;"> 
                        <input type="text" id="searchField" class="form-control" placeholder="Search Students..."> 
                        <a type="button" href="create.php" class="btn btn-primary" style="margin-left: 12px;">New Authorize Person</a>
                    </div>
                    <hr>
                    <br>
                    <div class="container">
                        <div class="row" id="card-list">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            searchData();
        })

        $("#searchField").on('keyup', function() {
                // Clear the previous timer (if any)
            // searchData($("#searchField").val());
            searchData($("#searchField").val());
        });

        function searchData(search = ''){
            $("#card-list").html('');
             // Make the AJAX GET request with parameters
            $.ajax({
                url: 'index-search-api.php',  // Replace with your PHP script file
                type: 'GET',
                data: { search: search, parentId : "<?=$_SESSION['id']?>" },  // Send parameters in the query string
                success: function(response) {
                    // Handle the response (e.g., display in a div)
                    console.log(response);
                    response?.forEach(obj => {
                        $("#card-list").append(`
                            <div class="col-lg-3 col-md-4 col-sm-6">
                                <div class="card-body">
                                    <img src="data:image/png;base64,${obj.picture}" alt="">
                                    <div class="details">
                                        <p>${obj.fullname}</p>
                                        <small>${obj.contact_number}</small>
                                    </div>
                                    <div class="action">
                                        <a type="button" href="edit.php?id=${obj.id}" class="btn btn-dark">Edit</a>
                                        <button ident="${obj.id}" name="btnArchive" class="btn btn-danger">Archive</button>
                                    </div>
                                </div>
                            </div>
                        `)
                    });
                },
                error: function(xhr, status, error) {
                    // Handle error
                    console.log("An error occurred: " + error);
                }
            });
        }

    $(document).on("click", "button[name='btnArchive']", function() {
    var id = $(this).attr('ident');
    if (confirm("Are you sure you want to archive this authorized person?")) {
        $.ajax({
            url: "archive.php",  // PHP script that performs the archiving
            type: "POST",
            data: { id: id },
            success: function(response) {
                // Ensure response is an object
                try {
                    var data = JSON.parse(response);
                    alert(data?.message || "Action completed.");
                    if (data.status === 'success') {
                        // Optionally update the UI (remove the row, for example)
                        searchData($("#searchField").val());
                    }
                } catch (e) {
                    alert("Error parsing server response.");
                }
            },
            error: function(xhr, status, error) {
                alert("An error occurred: " + error);
            }
        });
    }
});


    </script>
</body>
</html>
