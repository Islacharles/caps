<?php
include '../../Config/api-config.php';
include '../../Config/connection.php'; // Opening database connection

// Ensure the request method is DELETE
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode([
        "status" => "error",
        "message" => "Invalid request method. Only DELETE is allowed."
    ]);
    exit();
}

// Parse the input JSON to get the ID
parse_str(file_get_contents("php://input"), $requestData);
$id = $requestData['id'] ?? null;

// Validate the ID
if (empty($id) || !is_numeric($id)) {
    http_response_code(400); // Bad Request
    echo json_encode([
        "status" => "error",
        "message" => "Invalid or missing ID."
    ]);
    exit();
}

// SQL query to delete the record
$sql = "DELETE FROM authorize_person WHERE ID = ?";

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind the ID parameter
$stmt->bind_param("i", $id);

// Execute the query and check if the record was deleted
if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode([
            "status" => "success",
            "message" => "Record deleted successfully."
        ]);
    } else {
        http_response_code(404); // Not Found
        echo json_encode([
            "status" => "error",
            "message" => "Record not found."
        ]);
    }
} else {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        "status" => "error",
        "message" => "Failed to delete the record. Please try again."
    ]);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
