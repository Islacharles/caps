<?php
include '../../Config/api-config.php';
include '../../Config/connection.php'; // Open database connection

$search = $_GET['search'] ?? '';
$parentId = $_GET['parentId']?? '' ;

// SQL query
$sql = "SELECT 
            ap.ID as 'ID',
            ap.FIRSTNAME,
            ap.MIDDLENAME,
            ap.LASTNAME,
            ap.CONTACT_NUMBER,
            ap.ADDRESS,
            ap.PARENT_ID,
            ap.PICTURE
        FROM 
            authorize_person ap
        WHERE 
            CONCAT(ap.FIRSTNAME, ap.MIDDLENAME, ap.LASTNAME, ap.ADDRESS, ap.PARENT_ID) LIKE ?
            AND ap.PARENT_ID = ?";

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind parameter (s for string) to the prepared statement
$searchTermWithWildcards = "%" . $search . "%"; // Add '%' for LIKE operator
$stmt->bind_param("ss", $searchTermWithWildcards, $parentId); // Bind the parameter as a string

// Execute the query
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Initialize an array to hold the response data
$response = [];

// Fetch all the rows and add them to the response array
while ($row = $result->fetch_assoc()) {
    $response[] = array(
        'id' => $row["ID"],
        'fullname' => $row["FIRSTNAME"] . " " . $row["LASTNAME"],
        'contact_number' => $row["CONTACT_NUMBER"],
        'address' => $row["ADDRESS"],
        'parent_id' => $row["PARENT_ID"],
        'picture' => $row["PICTURE"]
    );
}

// Respond with the JSON data
echo json_encode($response, JSON_PRETTY_PRINT);

// Close the connection
$stmt->close();
$conn->close();

?>
