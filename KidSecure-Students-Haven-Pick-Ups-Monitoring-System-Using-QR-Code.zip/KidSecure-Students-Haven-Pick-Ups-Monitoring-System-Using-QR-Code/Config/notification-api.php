<?php

function createNotification($userId, $title, $redirection, $description, $studentId){
    // // Insert into notifications table
    // $sqlNotif = "INSERT INTO notifications (USER_ID, TITLE, REDIRECTION, 'DESCRIPTION', STUDENT_ID) 
    //         VALUES (?, ?, ?, ?, ?)";
    // $stmtNotif = $conn->prepare($sqlNotif);

    // // Bind parameters and execute
    // $stmtNotif->bind_param("isssi", $userId, $title, $redirection, $description, $studentId);

    // // Close the statement and connection
    // $stmtNotif->close(); 


        $title = 'Attendance';
        $redirection = '/student/view.php?id=' . $studentId;
        $description = $studentName . ' has been Time out on school with - ' . $authorizeName;
        // Insert into notifications table
        $sqlNotif = "INSERT INTO notifications (USER_ID, TITLE, REDIRECTION, DESCRIPTION, STUDENT_ID) VALUES (?, ?, ?, ?, ?)";
        $stmtNotif = $conn->prepare($sqlNotif);
        // Bind parameters and execute
        $stmtNotif->bind_param("isssi", $userId, $title, $redirection, $description, $studentId);
        $stmtNotif->execute();
        // Close the statement and connection
        $stmtNotif->close();
}

?>
