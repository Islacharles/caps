<?php
$host = 'localhost';
$dbname = 'kidsecdb';
$username = 'root';
$password = '';

// Create a connection using MySQLi
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$result = $conn->query("SELECT 1");
if (!$result) {
    die("Database connection failed: " . $conn->error);
}

?>