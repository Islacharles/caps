<?php
    // Check if user is logged in
    if (!isset($_SESSION['id']) || !$_SESSION['logged_in']) {
        header("Location: ../login.php");
        exit();
    }else{
        // Retrieve user information from the session
        $fullname = $_SESSION['fullname'];
        $role = $_SESSION['role'];
        $user_id = $_SESSION['id']; // Get the logged-in user's ID

        
        $sql = "SELECT profile_image FROM admin_staff WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id); // Bind the user ID to the query
        $stmt->execute();
        $stmt->bind_result($profile_image);
        $stmt->fetch();
        $stmt->close();

        // If the profile image is empty, you can use a default image
        if (empty($profile_image)) {
            $profile_image = 'path/to/default-image.jpg'; // Provide the path to a default image
        } 
    } 
?>