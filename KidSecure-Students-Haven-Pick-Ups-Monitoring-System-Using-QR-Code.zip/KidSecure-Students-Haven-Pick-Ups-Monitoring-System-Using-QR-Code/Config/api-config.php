<?php
// Set the response header to JSON
header('Content-Type: application/json');

?>