<?php
session_start(); // Start the session
include '../../Config/connection.php';
$_SESSION['header'] = 'QR Scan Attendance';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.css" rel="stylesheet"/> <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/html5-qrcode/minified/html5-qrcode.min.js"></script>

    <title>Teacher Details</title>
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main">
        <div class="main-wrapper-body">  
            <div class="row">
                <div class="col-4">
                    <div class="card card-container">
                        <div id="reader" style="width: 100%; height: 500px;"></div>
                    </div>
                </div>
                <div class="col-8" id="student-content">
                    <div class="card card-container">
                        <div class="row">
                            <div class="col-4">
                                <img src="" alt="" class="user-img" id="imgUser">
                            </div>
                            <div class="col-8">
                                <div class="form-group">
                                    <label for="txtFirstName">Full Name</label>
                                    <input type="text" class="form-control" id="txtfullname" name="frmGroup" disabled value="" aria-describedby="txtName" placeholder="Enter First Name">
                                </div>
                                <div class="form-group">
                                    <label for="txtGrade">Grade</label>
                                    <input type="text" class="form-control" id="txtGrade" name="frmGroup" disabled value="" aria-describedby="txtName" placeholder="Enter First Name">
                                </div>
                                <div class="form-group">
                                    <label for="txtSection">Section</label>
                                    <input type="text" class="form-control" id="txtSection" name="frmGroup" disabled value="" aria-describedby="txtName" placeholder="Enter First Name">
                                </div>
                                <div class="form-group">
                                    <label for="txtBirthDate">Date</label>
                                    <input type="date" class="form-control" id="txtBirthDate" name="frmGroup" disabled value="" aria-describedby="txtName" placeholder="Enter First Name">
                                </div>
                                <br/>
                                <h1 class="text-success"><b id="txtTimeAction"></b></h1>
                                <br>
                                <h4>Select Authorize Person</h4>
                                <hr>
                                <div class="row" id="authorizePersons">
                                    <!-- Select authorized persons will be appended here -->
                                </div>
                                
                                
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script>
    // Initialize the QR scanner
    let qrCodeScanner;
    let qrStatus = true;
    $(document).ready(function(){
        // Initialize the scanner with the element
        reinitializeQRCode();
        $("#student-content").hide();
    });

    // On successful QR code scan
    function onScanSuccess(decodedText, decodedResult) {
        if(qrStatus){
            qrStatus = false;
            $('#result').text(decodedText);
            console.log('QR Code scanned: ', decodedText);
            onQRScanAttendance(decodedText);
            setTimeout(() => {
                qrStatus = true;
            }, 3500);
        }
    }

    function reinitializeQRCode(){
        qrCodeScanner = new Html5QrcodeScanner(
            "reader", 
            { fps: 5, qrbox: 300 }, 
            /* verbose= */ false
        );
        // Start scanning
        qrCodeScanner.render(onScanSuccess, onScanFailure);
    }

    // On scan failure
    function onScanFailure(error) {
        // Handle QR scan error if needed
    }

    function onQRScanAttendance(qrtext) {
        $.ajax({
            url: 'qr-attendance-api.php', // The PHP script that will handle the request
            type: 'POST',
            data: {
                qrcode_value: qrtext
            },
            success: function(response) {
                console.log(response);
                $("#txtfullname").val(response.student_firstname + ' ' + response.student_lastname);
                $("#txtGrade").val(response.GRADE_LEVEL);
                $("#txtSection").val(response.SECTION);
                $("#txtBirthDate").val(response.CurrentDateNow);
                $("#imgUser").attr("src", `data:image/png;base64,${response.PICTURE}`);
                $("#txtTimeAction").html(response.action);

                // Hide the "Select Authorize Person" section by default
                $("#authorizePersons").html('');
                $("#student-content").find('h4').hide(); // Hide the header initially

                if (response.action === 'TIME OUT') {
                    // Show the "Select Authorize Person" header and content if action is TIME OUT
                    $("#student-content").find('h4').show(); // Show the header
                    response?.authorizePersons?.forEach(obj => {
                        $("#authorizePersons").append(
                            `<div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="card-body">
                                    <img src="data:image/png;base64,${obj.PICTURE}" alt=""/>
                                    <div class="details">
                                        <p>${obj.first_name} ${obj.last_name}</p>
                                        <small>${obj.role}</small>
                                    </div>
                                    <div class="action">
                                        <button name="selectPerson" authName='${obj.first_name} ${obj.last_name}' studentName='${response.student_firstname} ${response.student_lastname}' studentId='${response.student_id}' parentId='${response.PARENT_ID}' ident="${obj.person_id}" attendance-ident="${response?.attendance?.ID}" class="btn btn-primary">
                                            <i class="fas fa-check" style="display: none;"></i>
                                            Select
                                        </button>
                                    </div>
                                </div>
                            </div>`
                        );
                    });
                }

                // Show the student content
                $("#student-content").show();
            },
            error: function(xhr, status, error) { 
                console.log(error);
            }
        });
    }

    $(document).ready(function(){
    let selectedAuthorizePersonId = null;  // Variable to hold the selected authorized person's ID
    let selectedAttendanceId = null;  // Variable to hold the attendance ID

    // Handle selection of an authorized person
    $(document).on('click', "button[name='selectPerson']", function(){
        const authId = $(this).attr('ident');
        const attendanceId = $(this).attr('attendance-ident'); 
        const parentId = $(this).attr('parentId'); 
        const studentId = $(this).attr('studentId'); 
        const studentName = $(this).attr('studentName'); 
        const AuthName = $(this).attr('authName'); 

        // Store the selected attendance ID and authorized person ID
        selectedAttendanceId = attendanceId;
        selectedAuthorizePersonId = authId;

        // Replace "Select" button with a check icon once selected
        $(this).html('<i class="fas fa-check"></i>'); // Show check sign
        $(this).prop('disabled', true); // Disable the button after selection
        $(this).toggleClass('selected');

        // Now send the selection data via AJAX
        $.ajax({
            url: 'select-person-api.php', // The PHP script that will handle the request
            type: 'POST',
            data: {
                attendance_id: attendanceId,
                authorize_id: authId,
                parent_id: parentId,
                student_id: studentId,
                student_name: studentName,
                authorize_name: AuthName
            },
            success: function(response) { 
                console.log(response);
                if(response.status === 'success'){
                    alert(response.message);

                    // Hide the student content after successful selection
                    $("#student-content").hide(); // Hides the student details

                    // Optionally, you can clear the student details here if required
                    $("#txtfullname").val('');
                    $("#txtGrade").val('');
                    $("#txtSection").val('');
                    $("#txtBirthDate").val('');
                    $("#imgUser").attr("src", '');
                    $("#txtTimeAction").html('');

                    // Clear the authorize persons
                    $("#authorizePersons").html('');
                } else {
                    alert(response.message);
                }
            },
            error: function(xhr, status, error) { 
                console.log(error);
            }
        });
    });
});

</script>

</body>
</html>
