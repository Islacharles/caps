<?php
session_start(); // Start the session
include '../../Config/connection.php';
$_SESSION['header'] = 'Student Attendance';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="index.css" rel="stylesheet" />
    <title>Student Attendance Table</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Include Local DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="datatables.min.css">
    <style>
        .table-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main">
        <div class="main-wrapper-body card-container">
            <!-- Container -->
            <div class="container"> 

                <!-- Filters -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <!-- Date filter -->
                        <input type="date" class="form-control" id="filterDate" placeholder="Filter by Date">
                    </div>
                    <div class="col-md-6">
                        <!-- Search input -->
                        <input type="text" class="form-control" id="searchStudent" placeholder="Search Student">
                    </div>
                </div>

                <!-- Table -->
                <div class="table-container">
                    <table class="table table-striped table-bordered" id="attendanceTable">
                        <thead class="table-dark">
                            <tr>
                                <th>Student #</th>
                                <th>Full Name</th>
                                <th>Grade Level</th>
                                <th>Section</th>
                                <th>Date</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Authorize Person</th>
                            </tr>
                        </thead>
                        <tbody id="body-table">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Local jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- Include Local DataTables JS -->
    <script src="datatables.min.js"></script>
    <!-- Include Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function () {
            // Initialize DataTable
            var table = $('#attendanceTable').DataTable();

            // Set default date to today
            var today = new Date();
            var yyyy = today.getFullYear();
            var mm = today.getMonth() + 1; // Months are zero-based
            var dd = today.getDate();

            // Format the month and day to be two digits
            if (mm < 10) mm = '0' + mm;
            if (dd < 10) dd = '0' + dd;

            // Construct the date in yyyy-MM-dd format
            var formattedDate = yyyy + '-' + mm + '-' + dd;
            $('#filterDate').val(formattedDate);

            fetchData();

            // Trigger data fetching on filter changes
            $("#filterDate, #searchStudent").on('input', function () {
                fetchData();
            });

            function fetchData() {
                var search = $('#searchStudent').val();
                var date = $('#filterDate').val();

                // AJAX GET request
                $.ajax({
                    url: 'search-attendance-api.php', // API URL
                    method: 'GET',
                    data: {
                        search: search,
                        date: date
                    },
                    success: function (response) {
                        table.clear(); // Clear existing table data
                        response?.forEach(function (item) {
                            table.row.add([
                                item.student_number,
                                item.student_name,
                                item.grade_level,
                                item.section,
                                item.created_date,
                                item.time_in,
                                item.time_out,
                                item.authorize_fullname
                            ]);
                        });
                        table.draw(); // Redraw the table with new data
                    },
                    error: function () {
                        alert('An error occurred while fetching the data.');
                    }
                });
            }
        });
    </script>
</body>
</html>
