<?php
// login.php

// Start session
session_start();

include 'Config/connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get input values
    $email = $_POST['email'];
    $password = $_POST['password'];
    // SQL query to check the email
    $sql = "
        SELECT * FROM (SELECT 
            id, 
            email, 
            password, 
            fullname, 
            'admin' AS role ,
            profile_image as picture
        FROM 
            admin_staff
        UNION
        SELECT 
            id, 
            email, 
            password, 
            CONCAT(firstname, ' ', lastname) AS fullname, 
            'teacher' AS role ,
            picture as picture
        FROM 
            teachers
        UNION
        SELECT 
            id, 
            email, 
            password, 
            CONCAT(firstname, ' ', lastname) AS fullname, 
            'guardian' AS role ,
            picture as picture
        FROM 
            guardian) as AD
        WHERE email = ? and password = ?
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if email exists and validate password
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // After successful password verification
        generateSession($user);
        if(strtolower($user['role']) === "admin"){
            header("Location: Admin/attendance"); // Redirect to dashboard
            exit();
        }else if(strtolower($user['role']) === "teacher"){
            header("Location: Teacher/"); // Redirect to dashboard
            exit();
        }else if(strtolower($user['role']) === "guardian"){
            header("Location: Guardian/"); // Redirect to dashboard
            exit();
        }
    }else {
        $error = "Email & Password Doesn't exist";
    }

    // // SQL query to check the email of User
    // $sqlParents = "SELECT * FROM parent_acc WHERE email = ?";
    // $stmtParents = $conn->prepare($sqlParents);
    // $stmtParents->bind_param('s', $email);
    // $stmtParents->execute();
    // $resultParents = $stmtParents->get_result();
    
    // // Check if email exists and validate password
    // if ($resultParents->num_rows > 0) {
    //     $userParents = $resultParents->fetch_assoc();
    //     if (password_verify($password, $userParents['password'])) {
    //         // After successful password verification
    //         generateSession($user);
    //         header("Location: User front/dashboard.php"); // Redirect to dashboard
    //         exit();
    //     } else {
    //         $error = "Email & Password Doesn't exist";
    //     }
    // }
}

function generateSession($userDetails){
    // Set session variables for logged-in user
    $_SESSION['email'] = $userDetails['email'];
    $_SESSION['id'] = $userDetails['id'];  // Store user ID
    $_SESSION['role'] = $userDetails['role'];  // Assuming 'role' is a column in your 'admin_staff' table
    $_SESSION['fullname'] = $userDetails['fullname'];  // Assuming 'fullname' is a column in your 'admin_staff' table
    $_SESSION['picture'] = $userDetails['picture'];  // Assuming 'fullname' is a column in your 'admin_staff' table
    $_SESSION['logged_in'] = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <?php include 'Config/jslib.php'; ?>

    <style>
        /* Global Reset */
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
        }

        /* Background Image */
        body {
            background-image: url('assets/aa.jpg'); /* Use the image as the background */
            background-size: cover; /* Ensure the image covers the entire screen */
            background-position: center; /* Center the image */
            background-repeat: no-repeat;
        }

        /* Centered Login Container */
        .login-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.85); /* Semi-transparent background */
            border-radius: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .login-container img {
            max-width: 120px;
            height: auto;
            margin-bottom: 20px;
        }

        .login-container h2 {
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }

        .login-container label {
            display: block;
            margin-bottom: 5px;
            color: #666;
            text-align: left;
            font-size: 14px;
        }

        .login-container input[type="email"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
            font-size: 14px;
        }

        .login-container button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background: linear-gradient(90deg, #6a11cb, #2575fc);
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .login-container button:hover {
            background: linear-gradient(90deg, #2575fc, #6a11cb);
        }

        .login-container a {
            color: #6a11cb;
            text-decoration: none;
            font-size: 14px;
            display: block;
            margin-top: 10px;
        }

        .login-container a:hover {
            text-decoration: underline;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        /* Responsive Design */
        @media (max-width: 480px) {
            .login-container h2 {
                font-size: 20px;
            }

            .login-container button {
                font-size: 14px;
            }

            .login-container input[type="email"],
            .login-container input[type="password"] {
                font-size: 12px;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <img src="assets/logo.png" alt="Logo">
        <h2>Login</h2>

        <!-- Display error if any -->
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Login form -->
        <form method="POST" action="">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
        <a href="resetPassword.php">Forgot Password?</a>
    </div>
</body>
</html>


<?php
// Close the database connection
$conn->close();
?>
