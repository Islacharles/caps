<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';
$_SESSION['header'] = 'Create Student';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Student</title>
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <link href="create.css" rel="stylesheet"/>
    <div class="container-main">
        <div class="main-wrapper-body card-container">
            <hr>
            <div class="row">
                <div class="col-2">
                    <img src="#" alt="" class="user-img" id="imgUser" name="frmGroup">
                    <small class="form-text text-danger" ident="imgUser" name="frmGroup"></small>
                    <button class="btn btn-dark upload-btn" id="btnUpload">Upload</button>
                    <input type="file" id="txtChooseFile" hidden accept=".jpg, .jpeg, .png">
                </div>
                <div class="col-10">
                    <div class="form-group">
                        <label for="txtFirstName">First Name</label>
                        <input type="text" class="form-control" id="txtFirstName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="FirstName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtMiddleName">Middle Name</label>
                        <input type="text" class="form-control" name="frmGroup" id="txtMiddleName" aria-describedby="txtName" placeholder="Enter Middle Name">
                        <small ident="MiddleName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtLastName">Last Name</label>
                        <input type="text" class="form-control" id="txtLastName" name="frmGroup" aria-describedby="txtName" placeholder="Enter Last Name">
                        <small  ident="LastName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtBirthDate">Date of Birth</label>
                        <input type="date" class="form-control" id="txtBirthDate" name="frmGroup" aria-describedby="txtName" placeholder="Enter Date of Birth">
                        <small  ident="BirthDate" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGradeLevel">Grade Level</label>
                        <select name="frmGroup" id="txtGradeLevel" class="form-control">
                            <option value="NURSERY">NURSERY</option>
                            <option value="KINDERGARTEN">KINDERGARTEN</option>
                            <option value="GRADE 1">GRADE 1</option>
                            <option value="GRADE 2">GRADE 2</option>
                            <option value="GRADE 3">GRADE 3</option>
                            <option value="GRADE 4">GRADE 4</option>
                            <option value="GRADE 5">GRADE 5</option>
                            <option value="GRADE 6">GRADE 6</option>
                        </select>
                        <small ident="GradeLevel" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtSection">Section</label>
                        <input type="text" class="form-control" id="txtSection" name="frmGroup" aria-describedby="txtName" placeholder="Enter Section">
                        <small  ident="Section" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtAddress">Address</label>
                        <textarea id="txtAddress" class="form-control" name="frmGroup" row="3"></textarea>
                        <small ident="Address" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <br/>
                    <br>
                </div>
                <h3>Guardian Details</h3>
                <hr>
                <div class="col-2">
                    <img src="" alt="" class="user-img" id="imgGuardianUser" name="frmGroup">
                    <small class="form-text text-danger" ident="imgGuardianUser" name="frmGroup"></small>
                    <button class="btn btn-dark upload-btn" id="btnGuardianUpload">Upload</button>
                    <input type="file" id="txtGuardianChooseFile" hidden accept=".jpg, .jpeg, .png">
                </div>
                <div class="col-10">
                    <div class="form-group">
                        <label for="txtGuardianFirstName">First Name</label>
                        <input type="text" class="form-control" id="txtGuardianFirstName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="GuardianFirstName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianMiddleName">Middle Name</label>
                        <input type="text" class="form-control" name="frmGroup" id="txtGuardianMiddleName" aria-describedby="txtName" placeholder="Enter Middle Name">
                        <small ident="GuardianMiddleName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianLastName">Last Name</label>
                        <input type="text" class="form-control" id="txtGuardianLastName" name="frmGroup" aria-describedby="txtName" placeholder="Enter Last Name">
                        <small  ident="GuardianLastName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianContactNumber">Contact Number</label>
                        <input type="text" class="form-control" id="txtGuardianContactNumber" name="frmGroup" aria-describedby="txtName" placeholder="Enter Contact Number">
                        <small  ident="GuardianContactNumber" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianAddress">Address</label>
                        <textarea id="txtGuardianAddress" class="form-control" name="frmGroup" row="3"></textarea>
                        <small ident="GuardianAddress" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtGuardianEmail">Email</label>
                        <input type="Email" class="form-control" id="txtGuardianEmail" name="frmGroup" aria-describedby="txtName" placeholder="Enter Email">
                        <small  ident="GuardianEmail" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <br>
                    <hr>
                </div>
                <div class="col-12">
                    <div style="display:flex;justify-content: end;align-items:end;width:100%;">
                        <button class="btn btn" id="btnCancel" style="margin-right:12px;width:160px;">Cancel</button>
                        <button class="btn btn-primary" style="width:160px;" id="btnSubmit">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $(document).ready(function(){
        $("#imgUser").attr('src','../../assets/download.png')
        $("#imgGuardianUser").attr('src','../../assets/download.png')
    })

    let studentImageBase64 = '';
    let guardianImageBase64 = '';
    $("#btnUpload").on('click', function(){
        $("#txtChooseFile").click();
    });
    
    $("#btnGuardianUpload").on('click', function(){
        $("#txtGuardianChooseFile").click();
    });

    $("#txtChooseFile").on('change', function(){
        const file = event.target.files[0];
        studentImageBase64 = "";
        const validExtensions = ["image/jpeg","image/jpg", "image/png"]; // Allowed MIME types

        if (file && validExtensions.includes(file.type)) {
            // Clear any previous error
            // $("#error").hide();

            // Display the selected image in the <img> tag
            const reader = new FileReader();
            reader.onload = function (e) {
                $("#imgUser").attr("src", e.target.result);
                var base64String = reader.result.split(',')[1];
                studentImageBase64 = base64String;
            };
            reader.readAsDataURL(file);
        } else {
            // Show an error if the file is invalid
            // $("#error").text("Please select a valid JPEG or PNG image.").show();
            // $("#preview").hide();
            $("#txtChooseFile").val("")
        }
    })

    $("#txtGuardianChooseFile").on('change', function(){
        const file = event.target.files[0];
        guardianImageBase64 = "";
        const validExtensions = ["image/jpeg","image/jpg", "image/png"]; // Allowed MIME types

        if (file && validExtensions.includes(file.type)) {
            // Clear any previous error
            // $("#error").hide();

            // Display the selected image in the <img> tag
            const reader = new FileReader();
            reader.onload = function (e) {
                $("#imgGuardianUser").attr("src", e.target.result);
                var base64String = reader.result.split(',')[1];
                guardianImageBase64 = base64String;
            };
            reader.readAsDataURL(file);
        } else {
            // Show an error if the file is invalid
            // $("#error").text("Please select a valid JPEG or PNG image.").show();
            // $("#preview").hide();
            $("#txtGuardianChooseFile").val("")
        }
    })

    $("#btnSubmit").on("click", function(){

        if(!confirm("Do you really want to submit?")){
            return;
        }
        if (!studentImageBase64) {
        studentImageBase64 = encodeDefaultImage("../../assets/download.png");
        }
        if (!guardianImageBase64) {
            guardianImageBase64 = encodeDefaultImage("../../assets/download.png");
        }

        let formData = new FormData();
        formData.append("FirstName", $("#txtFirstName").val());
        formData.append("MiddleName", $("#txtMiddleName").val());
        formData.append("LastName", $("#txtLastName").val());
        formData.append("BirthDate", $("#txtBirthDate").val());
        formData.append("GradeLevel", $("#txtGradeLevel").val());
        formData.append("Section", $("#txtSection").val());
        formData.append("Address", $("#txtAddress").val());

        
        formData.append("GuardianFirstName", $("#txtGuardianFirstName").val());
        formData.append("GuardianMiddleName", $("#txtGuardianMiddleName").val());
        formData.append("GuardianLastName", $("#txtGuardianLastName").val());
        formData.append("GuardianContactNumber", $("#txtGuardianContactNumber").val());
        formData.append("GuardianAddress", $("#txtGuardianAddress").val());
        formData.append("GuardianEmail", $("#txtGuardianEmail").val());

        formData.append("StudentPIctureBase64", studentImageBase64);

        formData.append("GuardianPIctureBase64", guardianImageBase64);

        clearErrorsForm();
         // Make AJAX POST request
        $.ajax({
            url: 'create-api.php', // Replace with your server endpoint
            type: 'POST',
            data: formData,
            processData: false, // Prevent jQuery from automatically transforming the data
            contentType: false, // Let the browser set the content type, including the boundary
            success: function (response) {
                // Parse JSON response and display it
                console.log(response)
                // Loop through JSON object and get field names
                $.each(response, function(fieldName, fieldValue) {
                    console.log("Field Name: " + fieldName); // Logs the field name (key)
                    $(`small[ident='${fieldName}']`).append(fieldValue + "<br/>");
                    $(`img[id='${fieldName}']`).attr("Style","border:1px solid red;");
                    $(`#txt${fieldName}`).addClass("is-invalid");
                });
                
                if(response?.status === 'success'){
                    alert(response?.message);
                    window.location.href = "index.php";
                }
            },
            error: function (xhr, status, error) {
                // Handle error
                console.log(error)
            }
        });
    })

    $("#btnCancel").on('click', function(){
        window.location.href="index.php"
    })

    function clearErrorsForm(){
        $("input[name='frmGroup']").removeClass("is-invalid");
        $("select[name='frmGroup']").removeClass("is-invalid");
        $("textarea[name='frmGroup']").removeClass("is-invalid");
        $("small[name='frmGroup']").html(""); 
        $(`img[name='frmGroup']`).attr("Style","");
    }
    function encodeDefaultImage(imagePath) {
    let img = new Image();
    img.src = imagePath;
    let canvas = document.createElement("canvas");
    let ctx = canvas.getContext("2d");
    canvas.width = 50;
    canvas.height = 50;
    let newWidth = 50;  
    let newHeight = 50;
    ctx.drawImage(img, 0, 0, newWidth, newHeight);
    return canvas.toDataURL("image/png").split(',')[1];
    }
</script>

</html>