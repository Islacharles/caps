<?php
include '../../Config/api-config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST'){
    exit();
}

// Collect data from POST
$firstName = $_POST["FirstName"] ?? '';
$middleName = $_POST["MiddleName"] ?? '';
$lastName = $_POST["LastName"] ?? '';
$birthDate = $_POST["BirthDate"] ?? '';
$gradeLevel = $_POST["GradeLevel"] ?? '';
$section = $_POST["Section"] ?? '';
$address = $_POST["Address"] ?? '';
$guardianFirstName = $_POST["GuardianFirstName"] ?? '';
$guardianMiddleName = $_POST["GuardianMiddleName"] ?? '';
$guardianLastName = $_POST["GuardianLastName"] ?? '';
$guardianContactNumber = $_POST["GuardianContactNumber"] ?? '';
$guardianAddress = $_POST["GuardianAddress"] ?? '';
$guardianEmail = trim($_POST["GuardianEmail"] ?? '');

$StudentPIctureBase64 = $_POST['StudentPIctureBase64'];
$GuardianPIctureBase64 = $_POST['GuardianPIctureBase64'];

// Initialize an array to store validation errors
$validationErrors = [];

// Validate each field
$validationErrors['FirstName'] = validateField('FirstName', $firstName);
// $validationErrors['MiddleName'] = validateField('MiddleName', $middleName);
$validationErrors['LastName'] = validateField('LastName', $lastName);
$validationErrors['GradeLevel'] = validateField('GradeLevel', $gradeLevel);
$validationErrors['Section'] = validateField('Section', $section);
$validationErrors['Address'] = validateField('Address', $address, 100);
$validationErrors['GuardianFirstName'] = validateField('GuardianFirstName', $guardianFirstName);
// $validationErrors['GuardianMiddleName'] = validateField('GuardianMiddleName', $guardianMiddleName);
$validationErrors['GuardianLastName'] = validateField('GuardianLastName', $guardianLastName);
$validationErrors['GuardianContactNumber'] = validateField('GuardianContactNumber', $guardianContactNumber, 11);
$validationErrors['GuardianAddress'] = validateField('GuardianAddress', $guardianAddress, 100);

// Validate BirthDate (example: required and valid date format)
if (empty($birthDate)) {
    $validationErrors['BirthDate'][] = "BirthDate is required.";
} elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthDate)) {
    $validationErrors['BirthDate'][] = "BirthDate must be in the format YYYY-MM-DD.";
}

// Validate GuardianEmail (example: required and valid email format)
if (empty($guardianEmail)) {
    $validationErrors['GuardianEmail'][] = "GuardianEmail is required.";
} elseif (!filter_var($guardianEmail, FILTER_VALIDATE_EMAIL)) {
    $validationErrors['GuardianEmail'][] = "Please provide a valid email address for the guardian.";
}

// Remove fields with no errors
foreach ($validationErrors as $key => $value) {
    if (empty($value)) {
        unset($validationErrors[$key]);
    }
}

// Respond with validation errors
if (!empty($validationErrors)) {
    echo json_encode($validationErrors, JSON_PRETTY_PRINT);
    exit();
}


include '../../Config/connection.php'; // openning connection
$studentId = "";
$guardianId = "";


$sql = "INSERT INTO `students`
        (FIRSTNAME, LASTNAME, MIDDLENAME, ADDRESS, BIRTHDATE, GRADE_LEVEL, SECTION, PICTURE)
        VALUES 
        (?, ?, ?, ?, ?, ?, ?, ?)";
// Prepare the statement
$stmt = $conn->prepare($sql);

$studentImage = ($StudentPIctureBase64 ? $StudentPIctureBase64 : NULL);
// Bind parameters to the statement
$stmt->bind_param("ssssssss",
    $firstName, 
    $lastName, 
    $middleName, 
    $address, 
    $birthDate, 
    $gradeLevel, 
    $section,
    $studentImage); // "sss" denotes that all parameters are strings


// Execute the query
if ($stmt->execute()) {
    $studentId = $stmt->insert_id;
} else {
    echo "Error: " . $stmt->error;
    exit();
}


// Prepare the SQL query to check for an existing guardian
$sqlCheckIfExist = "SELECT * FROM guardian WHERE EMAIL = ?";
$stmtCheckIfExist = $conn->prepare($sqlCheckIfExist);
$stmtCheckIfExist->bind_param("s", $guardianEmail);
// Execute the query
$stmtCheckIfExist->execute();
$resultCheckIfExist = $stmtCheckIfExist->get_result();

if ($resultCheckIfExist->num_rows === 0){

    $guardianSql = "INSERT INTO `guardian`
        (`FIRSTNAME`, `MIDDLENAME`, `LASTNAME`, `CONTACT_NUMBER`, `ADDRESS`, `PICTURE`, `EMAIL`, `PASSWORD`)
        VALUES
        (?, ?, ?, ?, ?, ?, ?, ?);";

    // Prepare the statement
    $guardianstmt = $conn->prepare($guardianSql);

    $guardianImage = $GuardianPIctureBase64 ? $GuardianPIctureBase64 : NULL;
    $password = (strtolower($guardianFirstName . $guardianLastName));
    // Bind parameters to the statement
    $guardianstmt->bind_param("ssssssss", 
        $guardianFirstName, 
        $guardianMiddleName, 
        $guardianLastName, 
        $guardianContactNumber, 
        $guardianAddress, 
        $guardianImage, 
        $guardianEmail, 
        $password
    );
    $guardianstmt->execute();
    $guardianId = $guardianstmt->insert_id;
    $guardianstmt->close();

}else{
    $guardianDetails = $resultCheckIfExist->fetch_assoc();
    $guardianId = $guardianDetails['ID'];
}
$stmtCheckIfExist->close();







// Prepare the insert query
$bindsql = "INSERT INTO `student_guardian` (`STUDENT_NUMBER`, `PARENT_ID`)
        VALUES (?, ?)";

// Prepare the statement
$bindstmt = $conn->prepare($bindsql);

// Bind parameters to the statement
$bindstmt->bind_param("ii", $studentId, $guardianId);

// Execute the query
$bindstmt->execute();


// Prepare the insert query
$sqlqrcode = "INSERT INTO `student_qrcode` (QR_CODE, STUDENT_NUMBER) VALUES (?, ?)";
// Prepare the statement
$stmtqrcode = $conn->prepare($sqlqrcode);
$qrcodevalue = generateAssignedQRCode($studentId);
// Bind the parameters
$stmtqrcode->bind_param("si", $qrcodevalue , $studentId);
$stmtqrcode->execute();

// Close the statement and the connection
$stmt->close();  
$bindstmt->close();
$stmtqrcode->close();
$conn->close(); 

$response = array(
    'status' => 'success',
    'message' => 'Record inserted successfully!'
);
// Send the response as JSON
echo json_encode($response);
// Helper function to validate input fields
function validateField($fieldName, $fieldValue, $maxLength = 50) {
    $errors = [];

    // Check if the field is required and not empty
    if (empty($fieldValue)) {
        $errors[] = "$fieldName is required.";
    }

    // Check length
    if (!empty($fieldValue) && strlen($fieldValue) > $maxLength) {
        $errors[] = "$fieldName must not exceed $maxLength characters.";
    }

    // Check for special characters
    if (!empty($fieldValue) && preg_match('/[^a-zA-Z0-9\s]/', $fieldValue)) {
        $errors[] = "$fieldName must not contain special characters.";
    }

    return $errors;
}


function generateAssignedQRCode($studId){
    // Get the current datetime in 'yyyyMMddHHmmss' format
    $dateTime = date('YmdHis');

    // Generate a 16-character random string (letters and numbers)
    $randomString = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'), 0, 16);

    // Combine the datetime, fixed value, and random string
    $finalString = $dateTime . $studId . $randomString;

    // Output the result
    return $finalString;
}
?>