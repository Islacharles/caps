<?php
session_start(); // Start the session
include '../../Config/connection.php';

$_SESSION['header'] = 'Create Teachers';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="create.css" rel="stylesheet"/>
    <title>Create Teacher</title>
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main">
        <div class="main-wrapper-body">
            <hr>
            <div class="row">
                <div class="col-2">
                    <img src="data:image/png;base64," alt="" class="user-img" id="imgUser" name="frmGroup">
                    <small class="form-text text-danger" ident="imgUser" name="frmGroup"></small>
                    <button class="btn btn-dark upload-btn" id="btnUpload">Upload</button>
                    <input type="file" id="txtChooseFile" hidden accept=".jpg, .jpeg, .png">
                </div>
                <div class="col-10">
                    <div class="form-group">
                        <label for="txtFirstName">First Name</label>
                        <input type="text" class="form-control" id="txtFirstName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="FirstName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtMiddleName">Middle Name</label>
                        <input type="text" class="form-control" id="txtMiddleName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="MiddleName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtLastName">Last Name</label>
                        <input type="text" class="form-control" id="txtLastName" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="LastName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtBirthDate">Date of Birth</label>
                        <input type="date" class="form-control" id="txtBirthDate" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="BirthDate" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtContactNumber">Contact Number</label>
                        <input type="number" class="form-control" id="txtContactNumber" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="ContactNumber" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtEmail">Email</label>
                        <input type="text" class="form-control" id="txtEmail" name="frmGroup" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="Email" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtAddress">Address</label>
                        <textarea id="txtAddress" class="form-control" name="frmGroup" row="3"></textarea>
                        <small ident="Address" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <br/>
                    <br>
                </div>
                <div style="display:flex;justify-content: end;align-items:end;width:100%;">
                    <a class="btn btn" type="button" href="index.php" id="btnCancel" style="margin-right:12px;width:160px;">Cancel</a>
                    <button class="btn btn-primary" style="width:160px;" id="btnSubmit">Submit</button>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    let teacherImageBase64 = '';
    $(document).ready(function(){

    })

    $(document).ready(function(){
        $("#imgUser").attr('src','../../assets/download.png') 
    })

    $("#btnUpload").on('click', function(){
        $("#txtChooseFile").click();
    });
    
    $("#txtChooseFile").on('change', function(){
        const file = event.target.files[0];
        studentImageBase64 = "";
        const validExtensions = ["image/jpeg","image/jpg", "image/png"]; // Allowed MIME types

        if (file && validExtensions.includes(file.type)) {
            // Clear any previous error
            // $("#error").hide();

            // Display the selected image in the <img> tag
            const reader = new FileReader();
            reader.onload = function (e) {
                $("#imgUser").attr("src", e.target.result);
                var base64String = reader.result.split(',')[1];
                teacherImageBase64 = base64String;
            };
            reader.readAsDataURL(file);
        } else {
            // Show an error if the file is invalid
            // $("#error").text("Please select a valid JPEG or PNG image.").show();
            // $("#preview").hide();
            $("#txtChooseFile").val("")
        }
    });

    
    $("#btnCancel").on('click', function(){
        clearErrorsForm();
    })

    function clearErrorsForm(){
        $("input[name='frmGroup']").removeClass("is-invalid");
        $("select[name='frmGroup']").removeClass("is-invalid");
        $("textarea[name='frmGroup']").removeClass("is-invalid");
        $("small[name='frmGroup']").html("");
        $(`img[name='frmGroup']`).attr("Style","");
    }

    
    $("#btnSubmit").on("click", function(){

        if(!confirm("Do you really want to submit?")){
            return;
        }
        if (!teacherImageBase64) {
            teacherImageBase64 = encodeDefaultImage("../../assets/download.png");
        }
        let formData = new FormData();
        formData.append("FIRSTNAME", $("#txtFirstName").val());
        formData.append("MIDDLENAME", $("#txtMiddleName").val());
        formData.append("LASTNAME", $("#txtLastName").val());
        formData.append("BIRTHDATE", $("#txtBirthDate").val());
        formData.append("ADDRESS", $("#txtAddress").val());
        formData.append("CONTACT_NUMBER", $("#txtContactNumber").val());
        formData.append("EMAIL", $("#txtEmail").val());
        formData.append("PICTURE", teacherImageBase64);

        clearErrorsForm();
        // Make AJAX POST request
        $.ajax({
            url: 'create-api.php', // Replace with your server endpoint
            type: 'POST',
            data: formData,
            processData: false, // Prevent jQuery from automatically transforming the data
            contentType: false, // Let the browser set the content type, including the boundary
            success: function (response) {
                // Parse JSON response and display it
                console.log(response)
                // Loop through JSON object and get field names
                $.each(response?.validation_errors, function(fieldName, fieldValue) {
                    console.log("Field Name: " + fieldName); // Logs the field name (key)
                    $(`small[ident='${fieldName}']`).append(fieldValue + "<br/>");
                    $(`#txt${fieldName}`).addClass("is-invalid");
                    $(`img[id='${fieldName}']`).attr("Style","border:1px solid red;");
                });
                
                if(response?.message === 'Teacher created successfully!'){
                    alert(response?.message);
                    window.location.href = "index.php";
                }
            },
            error: function (xhr, status, error) {
                // Handle error
                console.log(error)
            }
        });
    })
    function encodeDefaultImage(imagePath) {
    let img = new Image();
    img.src = imagePath;
    let canvas = document.createElement("canvas");
    let ctx = canvas.getContext("2d");
    canvas.width = 50;
    canvas.height = 50;
    let newWidth = 50;  
    let newHeight = 50;
    ctx.drawImage(img, 0, 0, newWidth, newHeight);
    return canvas.toDataURL("image/png").split(',')[1];
    }
</script>

</html>