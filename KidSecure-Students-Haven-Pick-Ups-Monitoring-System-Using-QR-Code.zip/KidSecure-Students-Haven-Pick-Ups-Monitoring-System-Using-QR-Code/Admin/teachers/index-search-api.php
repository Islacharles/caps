<?php
// Include necessary configuration and database connection files
include '../../Config/api-config.php';
include '../../Config/connection.php'; // Opening connection

// Get the search parameter
$search = $_GET['search'] ?? '';

// SQL query to fetch teachers
$sql = "SELECT 
            *
        FROM 
            teachers
        WHERE 
            CONCAT(FIRSTNAME, MIDDLENAME, LASTNAME, EMAIL, CONTACT_NUMBER) LIKE ?";

// Prepare the statement
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(['error' => 'Failed to prepare the statement.']);
    exit();
}

// Add wildcards for the search term
$searchTermWithWildcards = "%" . $search . "%";  

// Bind parameter (s for string)
$stmt->bind_param("s", $searchTermWithWildcards);

// Execute the query
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Initialize an array to hold the response data
$response = [];

// Fetch all rows and format the response
while ($row = $result->fetch_assoc()) {
    $response[] = array(
        'teacher_id' => $row["ID"],
        'default_data' => strtolower($row["FIRSTNAME"] . $row["LASTNAME"]),
        'teacher_name' => $row["FIRSTNAME"] . " " . $row["MIDDLENAME"] . " " . $row["LASTNAME"],
        'birthdate' => $row["BIRTHDATE"],
        'address' => $row["ADDRESS"],
        'contact_number' => $row["CONTACT_NUMBER"],
        'email' => $row["EMAIL"],
        'picture' => $row["PICTURE"]
    );
}

// Respond with the JSON data
echo json_encode($response, JSON_PRETTY_PRINT);

// Close the statement and connection
$stmt->close();
$conn->close();
?>
