<?php
include '../../Config/api-config.php';
include '../../Config/connection.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid request method. Use POST.']);
    exit();
}


// Collect data from POST request
$firstName = $_POST['FIRSTNAME'] ?? '';
$middleName = $_POST['MIDDLENAME'] ?? '';
$lastName = $_POST['LASTNAME'] ?? '';
$birthDate = $_POST['BIRTHDATE'] ?? '';
$address = $_POST['ADDRESS'] ?? '';
$contactNumber = $_POST['CONTACT_NUMBER'] ?? '';
$picture = $_POST['PICTURE'] ?? '';
$email = $_POST['EMAIL'] ?? '';
$password = (strtolower($_POST['FIRSTNAME'] ?? '') . strtolower($_POST['LASTNAME'] ?? ''));

// Initialize validation errors
$validationErrors = [];

// Helper function to validate fields
function validateField($fieldName, $value, $maxLength = 50, $allowSpecialChars = false) {
    $errors = [];

    // Check if required and not empty
    if (empty($value)) {
        $errors[] = "$fieldName is required.";
    }

    // Check max length
    if (!empty($value) && strlen($value) > $maxLength) {
        $errors[] = "$fieldName must not exceed $maxLength characters.";
    }

    // Check for special characters (if not allowed)
    if (!$allowSpecialChars && !empty($value) && preg_match('/[^a-zA-Z0-9\s]/', $value)) {
        $errors[] = "$fieldName must not contain special characters.";
    }

    return $errors;
}

// Validate each field
$validationErrors['FirstName'] = validateField('First Name', $firstName, 80); 
$validationErrors['LastName'] = validateField('Last Name', $lastName, 80);
$validationErrors['Address'] = validateField('Address', $address, 255, true); // Address can include special chars
$validationErrors['ContactNumber'] = validateField('Contact Number', $contactNumber, 15);
$validationErrors['Email'] = validateField('Email', $email, 120, true);

// Validate Birthdate (required and valid date format)
if (empty($birthDate)) {
    $validationErrors['BirthDate'][] = "Birthdate is required.";
} elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthDate)) {
    $validationErrors['BirthDate'][] = "Birthdate must be in YYYY-MM-DD format.";
}



// Validate Email format
if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $validationErrors['Email'][] = "Invalid email format.";
}

// Remove fields with no errors
foreach ($validationErrors as $key => $value) {
    if (empty($value)) {
        unset($validationErrors[$key]);
    }
}

// If validation errors exist, return them as a JSON response
if (!empty($validationErrors)) {
    echo json_encode(['validation_errors' => $validationErrors], JSON_PRETTY_PRINT);
    exit();
}

// Prepare the INSERT query
$sql = "INSERT INTO teachers (FIRSTNAME, MIDDLENAME, LASTNAME, BIRTHDATE, ADDRESS, CONTACT_NUMBER, PICTURE, EMAIL, PASSWORD)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    echo json_encode(['error' => 'Failed to prepare statement.']);
    exit();
}

// Bind parameters
$stmt->bind_param(
    "sssssssss",
    $firstName,
    $middleName,
    $lastName,
    $birthDate,
    $address,
    $contactNumber,
    $picture,
    $email,
    $password
);

// Execute the query and handle success or failure
if ($stmt->execute()) {
    echo json_encode(['message' => 'Teacher created successfully!', 'teacher_id' => $stmt->insert_id]);
} else {
    echo json_encode(['error' => 'Failed to insert record: ' . $stmt->error]);
}

// Close statement and connection
$stmt->close();
$conn->close();
?>