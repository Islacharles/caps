<?php
session_start(); // Start the session
include '../../Config/connection.php';

if(!isset($_GET['id'])){
    header("Location: index.php");
}


// SQL query to fetch teacher details based on teacher ID
$sql = "SELECT 
            ID, FIRSTNAME, MIDDLENAME, LASTNAME, BIRTHDATE, ADDRESS, 
            CONTACT_NUMBER, PICTURE, EMAIL 
        FROM teachers 
        WHERE ID = ?
        LIMIT 1";

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind the parameter (i for integer)
$stmt->bind_param("i", $_GET['id']);

// Execute the query
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Check if a record was found
if ($result->num_rows > 0) {
    // Fetch the details of the teacher
    $teacher = $result->fetch_assoc();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="edit.css" rel="stylesheet"/>
    <title>Teacher Details</title>
</head>
<body>
    <?php include '../shared/sidebar.php' ?>
    <div class="container-main">
        <div class="main-wrapper-body">
            <h2>Teacher Details</h2>
            <hr>
            <div class="row">
                <div class="col-2">
                    <img src="data:image/png;base64,<?=$teacher["PICTURE"]?>" alt="" class="user-img" id="imgUser">
                </div>
                <div class="col-10">
                    <div class="form-group">
                        <label for="txtFirstName">First Name</label>
                        <input type="text" class="form-control" id="txtFirstName" name="frmGroup" value="<?=$teacher["FIRSTNAME"]?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="FirstName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtMiddleName">Middle Name</label>
                        <input type="text" class="form-control" id="txtMiddleName" name="frmGroup" value="<?=$teacher["MIDDLENAME"]?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="MiddleName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtLastName">Last Name</label>
                        <input type="text" class="form-control" id="txtLastName" name="frmGroup" value="<?=$teacher["FIRSTNAME"]?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="LastName" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtBirthDate">Date of Birth</label>
                        <input type="date" class="form-control" id="txtBirthDate" name="frmGroup" value="<?=$teacher["BIRTHDATE"]?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="BirthDate" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtContactNumber">Contact Number</label>
                        <input type="number" class="form-control" id="txtContactNumber" name="frmGroup" value="<?=$teacher["CONTACT_NUMBER"]?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="ContactNumber" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtEmail">Email</label>
                        <input type="text" class="form-control" id="txtEmail" name="frmGroup" value="<?=$teacher["EMAIL"]?>" aria-describedby="txtName" placeholder="Enter First Name">
                        <small ident="Email" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="txtAddress">Address</label>
                        <textarea id="txtAddress" class="form-control" name="frmGroup" row="3" value="<?=$teacher["ADDRESS"]?>"><?=$teacher["ADDRESS"]?></textarea>
                        <small ident="Address" name="frmGroup" class="form-text text-danger"></small>
                    </div>
                    <br/>
                    <br>
                </div>
                <div style="display:flex;justify-content: end;align-items:end;width:100%;">
                    <a class="btn btn-primary" type="button" href="index.php" id="btnCancel" style="margin-right:12px;width:160px;">Cancel</a>
           
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    let teacherImageBase64 = null;
    $(document).ready(function(){

        $("input[name='frmGroup']").attr("disabled", true);
        $("select[name='frmGroup']").attr("disabled", true);
        $("textarea[name='frmGroup']").attr("disabled", true);
        $("small[name='frmGroup']").html("");
    })

    $("#btnCancel").on('click', function(){
        windows.location.href = "index.php"
    })
</script>

</html>