<?php

include '../../Config/connection.php';

$search = $_GET['search'] ?? '';

$query = "SELECT 
            g.ID as 'PARENT_NUMBER',
            CONCAT(FIRSTNAME, ' ', LASTNAME) AS FullName, 
            CONCAT(FIRSTNAME, LASTNAME) AS defaultPword,
            g.CONTACT_NUMBER, 
            g.EMAIL,
            g.PICTURE,
            (SELECT COUNT(*) FROM student_guardian WHERE PARENT_ID = g.ID) AS TOTAL_STUDENTS
          FROM 
            guardian as g
          WHERE 
            CONCAT(FIRSTNAME, ' ', LASTNAME) LIKE ?";

$stmt = $conn->prepare($query);
$searchParam = "%$search%";
$stmt->bind_param("s", $searchParam);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
$stmt->close();
$conn->close();
