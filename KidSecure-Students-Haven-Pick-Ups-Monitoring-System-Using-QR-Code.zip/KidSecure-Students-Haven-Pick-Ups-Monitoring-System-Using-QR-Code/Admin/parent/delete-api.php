<?php 
include '../../Config/api-config.php';
include '../../Config/connection.php'; // openning connection

// Get the student ID to delete
$parentId = $_POST['parent_id']; // or from URL, $_GET['student_id'] if needed

// Start a transaction to ensure all delete operations succeed or fail together
$conn->begin_transaction();

try {
    // Delete from student_guardian table
    $sql1 = "DELETE FROM student_guardian WHERE PARENT_ID = ?";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bind_param("i", $parentId);
    $stmt1->execute();

    // Delete from guardian table (make sure guardian exists for this student)
    $sql2 = "DELETE FROM guardian WHERE ID IN (SELECT PARENT_ID FROM student_guardian WHERE STUDENT_NUMBER = ?)";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->bind_param("i", $parentId);
    $stmt2->execute();

    // Delete from guardian table
    $sql3 = "DELETE FROM guardian WHERE ID = ?";
    $stmt3 = $conn->prepare($sql3);
    $stmt3->bind_param("i", $parentId);
    $stmt3->execute();

    // Commit the transaction
    $conn->commit();

    $response = array(
        'status' => 'success',
        'message' => 'Guardian and student related records deleted successfully!'
    );
    // Send the response as JSON
    echo json_encode($response); 
} catch (Exception $e) {
    // Rollback the transaction in case of error
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}

// Close the prepared statements and connection
$stmt1->close();
$stmt2->close();
$stmt3->close();
$conn->close();

?>