<?php
include '../../Config/api-config.php';  // Database configuration
include '../../Config/connection.php'; // Open connection

// Get data from POST request
$parentId = $_POST['parent_id'] ?? '';
$defaultPword = $_POST['defaultpw'] ?? '';
$defaultPword = ($defaultPword);

// Validate required fields
if (empty($parentId) ) {
    echo json_encode(['error' => 'Teacher ID and new password are required']);
    exit();
}


// SQL query to update the password
$updateSql = "UPDATE guardian SET PASSWORD = ? WHERE ID = ?";
$updateStmt = $conn->prepare($updateSql);
// Bind parameters (s for string, i for integer)
$updateStmt->bind_param("ss", $defaultPword,$parentId);

// Execute the update
if ($updateStmt->execute()) {
    $response = array(
        'status' => 'success',
        'message' => 'Password reset successfully!'
    );
} else {
    $response = array(
        'status' => 'error',
        'message' => 'Failed to update password: ' . $updateStmt->error
    );
}

// Send the response as JSON
echo json_encode($response);

// Close the statements and connection
$updateStmt->close();
$conn->close();
?>
