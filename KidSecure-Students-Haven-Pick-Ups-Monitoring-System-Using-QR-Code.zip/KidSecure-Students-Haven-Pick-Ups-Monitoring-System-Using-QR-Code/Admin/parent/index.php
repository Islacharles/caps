<?php
session_start(); // Start the session
include '../../Config/connection.php';
include '../../Config/auth.php';
$_SESSION['header'] = 'Guardians';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Parent Records</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="dataTables.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .table-img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <?php include '../shared/sidebar.php'; ?>
    <link href="index.css" rel="stylesheet" />
    <div class="container-main">
        <div class="main-wrapper-body card-container">
            <div class="row">
                <div class="col-md-12">
                    <div class="search-field mb-3" style="display: flex; justify-content: space-between;">
                        <h4>Guardian Records</h4>
                    </div>
                    <table class="table table-bordered table-hover align-middle" id="GuardianTable">
                        <thead class="table-dark">
                            <tr>
                                <th>Picture</th>
                                <th>Full Name</th>
                                <th>Contact Number</th>
                                <th>Students</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="dataTables.min.js"></script>
    <script>
        $(document).ready(function () {
            const table = $('#GuardianTable').DataTable({
                ajax: {
                    url: 'index-search-api.php',
                    type: 'GET',
                    dataSrc: ''
                },
                columns: [
                    {
                        data: 'PICTURE',
                        render: function (data) {
                            return `<img src="data:image/png;base64,${data}" class="table-img" alt="N/A">`;
                        }
                    },
                    { data: 'FullName' },
                    { data: 'CONTACT_NUMBER' },
                    { data: 'TOTAL_STUDENTS' },
                    { data: 'EMAIL' },
                    {
                        data: 'PARENT_NUMBER',
                        render: function (data, type, row) {
                            return `
                                <button class="btn btn-sm btn-primary btnReset" data-id="${data}" data-pw="${row.defaultPword}">Reset Password</button>
                                <a class="btn btn-dark btn-sm" href="view.php?id=${data}">View</a>
                                <button class="btn btn-danger btn-sm btnDelete" data-id="${data}">Delete</button>
                            `;
                        }
                    }
                ]
            });

            // Reset Password Functionality
            $('#GuardianTable').on('click', '.btnReset', function () {
                const parentId = $(this).data('id');
                const defaultPw = $(this).data('pw');
                if (confirm('Are you sure you want to reset this Guardian\'s password?')) {
                    $.ajax({
                        url: 'reset-api.php',
                        type: 'POST',
                        data: { parent_id: parentId, defaultpw: defaultPw },
                        success: function (response) {
                            alert(response?.message || 'Password reset successfully.');
                        },
                        error: function () {
                            alert('An error occurred while resetting the password.');
                        }
                    });
                }
            });

            // Delete Functionality
            $('#GuardianTable').on('click', '.btnDelete', function () {
                const parentId = $(this).data('id');
                if (confirm('Are you sure you want to delete this Guardian and their associated Students?')) {
                    $.ajax({
                        url: 'delete-api.php',
                        type: 'POST',
                        data: { parent_id: parentId },
                        success: function (response) {
                            alert(response?.message || 'Guardian deleted successfully.');
                            table.ajax.reload(); // Reload DataTable
                        },
                        error: function () {
                            alert('An error occurred while deleting the Guardian.');
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
