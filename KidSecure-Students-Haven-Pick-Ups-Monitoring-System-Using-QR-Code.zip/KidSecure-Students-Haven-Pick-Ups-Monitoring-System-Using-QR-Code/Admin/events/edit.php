<?php
include '../../Config/connection.php';

// Decode incoming JSON data
$data = json_decode(file_get_contents("php://input"), true);

// Extract fields from the data
$id = $data['id'];
$title = $data['title'];
$image = isset($data['image']) ? $data['image'] : null;
$description = isset($data['description']) ? $data['description'] : '';

// Check if the ID is provided and valid
if (!isset($id) || !is_numeric($id)) {
    echo json_encode(["message" => "Invalid or missing ID."]);
    exit;
}

// Prepare the SQL statement based on whether an image is provided
if ($image) {
    // If an image is provided, update the image as well
    $sql = "UPDATE events SET TITLE = ?, IMAGE = ?, DESCRIPTION = ? WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $title, $image, $description, $id);
} else {
    // If no image is provided, only update the title and description
    $sql = "UPDATE events SET TITLE = ?, DESCRIPTION = ? WHERE ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $title, $description, $id);
}

// Execute the statement and check for success
if ($stmt->execute()) {
    echo json_encode(["message" => "Event updated successfully!"]);
} else {
    echo json_encode(["message" => "Failed to update event."]);
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
